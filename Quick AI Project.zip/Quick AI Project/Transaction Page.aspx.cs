﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Quick_AI_Project
{
    public partial class Transaction_Page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string tableDiv = "";
            //string conString = "Data Source=DESKTOP-HHOK8FO\\SQLEXPRESS;Initial Catalog=project1;Integrated Security=True";
            //SqlConnection con = new SqlConnection(conString);
            //SqlCommand cmd = new SqlCommand("SELECT [Name], [Address], [Phone] FROM [yourTable]", con);
            //con.Open();
            //SqlDataReader dr = cmd.ExecuteReader();
            //tableDiv.Apend.DataSource = dr;
            //tableDiv.DataBind();
            //con.Close();

        }
    }
}