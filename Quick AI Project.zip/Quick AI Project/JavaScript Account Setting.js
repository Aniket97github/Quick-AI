﻿
<script>
    function ChangeStatus()
    {
        var status=document.getElementById("DropDownList2");
    if(status.value="Personal")
    {
        document.getElementById("txt").style.visibility = "hidden";

    }
    else
    {
        document.getElementById("txt").style.visibility="visible";
    }
    }
</script>

